<?php $__env->startSection('title', 'My Records'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <!-- Header -->
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
        <h2>
            <?php echo e($greeting); ?>, <?php echo e(auth()->user()->name); ?>!
        </h2>
    </div>


    <?php if(! $student): ?>

        <div class="alert alert-info">
            <i class="bi bi-info-circle me-1"></i>
            Your account is not linked to a student record yet. Please ask your teacher or the admin.
        </div>

    <?php else: ?>

        <?php if($student->needsAttention()): ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong>Academic Alert:</strong>
                <?php echo e(implode('; ', $student->alert_reasons)); ?>. Please see your adviser.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>


        <!-- My Statistics -->
        <div class="row mb-4">

            <div class="col-md-3 col-6 mb-3">
                <div class="card stat-card shadow-hover text-center">
                    <div class="card-body">
                        <h5 class="card-title text-muted">My GPA</h5>
                        <h2 class="card-text fw-bold text-primary-custom"><?php echo e(number_format((float) $student->gpa, 2)); ?></h2>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-6 mb-3">
                <div class="card stat-card shadow-hover text-center">
                    <div class="card-body">
                        <h5 class="card-title text-muted">Attendance</h5>
                        <h2 class="card-text fw-bold <?php echo e($student->hasLowAttendance() ? 'text-danger' : 'text-success'); ?>"><?php echo e($student->attendance_rate); ?>%</h2>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-6 mb-3">
                <div class="card stat-card shadow-hover text-center">
                    <div class="card-body">
                        <h5 class="card-title text-muted">Standing</h5>
                        <h2 class="card-text">
                            <span class="badge bg-<?php echo e($student->standing_color); ?> <?php echo e($student->standing_color === 'warning' ? 'text-dark' : ''); ?> fs-6">
                                <?php echo e($student->academic_standing); ?>

                            </span>
                        </h2>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-6 mb-3">
                <div class="card stat-card shadow-hover text-center">
                    <div class="card-body">
                        <h5 class="card-title text-muted">Absences</h5>
                        <h2 class="card-text fw-bold text-warning"><?php echo e($attendanceCounts['absent'] ?? 0); ?></h2>
                    </div>
                </div>
            </div>

        </div>


        <!-- My Profile -->
        <div class="bg-white p-4 rounded shadow-sm mb-4">
            <h5 class="mb-3 text-primary-custom">My Profile</h5>

            <table class="table mb-0">
                <tr>
                    <th style="width: 200px;">Student ID</th>
                    <td><?php echo e($student->student_id); ?></td>
                </tr>
                <tr>
                    <th>Program</th>
                    <td><?php echo e($student->program); ?></td>
                </tr>
                <tr>
                    <th>Year Level</th>
                    <td><?php echo e($student->year_level); ?></td>
                </tr>
                <tr>
                    <th>Units</th>
                    <td><?php echo e($student->units); ?></td>
                </tr>
            </table>
        </div>


        <div class="row">

            <!-- My Grades -->
            <div class="col-lg-7 mb-4">
                <div class="card h-100">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="bi bi-journal-text me-2"></i>
                            My Grades
                        </h5>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover align-middle">
                                <thead>
                                    <tr>
                                        <th>Subject</th>
                                        <th class="text-center">Units</th>
                                        <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th class="text-center"><?php echo e($label); ?></th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject => $subjectGrades): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php $byTerm = $subjectGrades->keyBy('term'); ?>
                                        <tr>
                                            <td><?php echo e($subject); ?></td>
                                            <td class="text-center"><?php echo e($subjectGrades->first()->units); ?></td>
                                            <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $termKey => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td class="text-center">
                                                    <?php if(isset($byTerm[$termKey])): ?>
                                                        <span class="badge status-badge bg-<?php echo e($byTerm[$termKey]->grade_color); ?> <?php echo e($byTerm[$termKey]->grade_color === 'warning' ? 'text-dark' : ''); ?>">
                                                            <?php echo e(number_format((float) $byTerm[$termKey]->grade, 2)); ?>

                                                        </span>
                                                    <?php else: ?>
                                                        <span class="text-muted">—</span>
                                                    <?php endif; ?>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="<?php echo e(2 + count($terms)); ?>" class="text-center text-muted py-4">No grades yet.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>


            <!-- My Attendance -->
            <div class="col-lg-5 mb-4">
                <div class="card h-100">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="bi bi-calendar-check me-2"></i>
                            My Attendance
                        </h5>

                        <small class="text-muted">
                            P <?php echo e($attendanceCounts['present'] ?? 0); ?> ·
                            L <?php echo e($attendanceCounts['late'] ?? 0); ?> ·
                            A <?php echo e($attendanceCounts['absent'] ?? 0); ?> ·
                            E <?php echo e($attendanceCounts['excused'] ?? 0); ?>

                        </small>
                    </div>

                    <div class="card-body p-0">
                        <ul class="list-group list-group-flush">
                            <?php $__empty_1 = true; $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <span><?php echo e($record->date->format('D, M d, Y')); ?></span>
                                    <span class="badge bg-<?php echo e($record->status_color); ?> <?php echo e($record->status_color === 'warning' ? 'text-dark' : ''); ?>">
                                        <?php echo e($record->status_label); ?>

                                    </span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="list-group-item text-center text-muted py-4">No attendance records yet.</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>

        </div>

    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lab1_2411600150\lab6_2411600150\resources\views/portal/dashboard.blade.php ENDPATH**/ ?>