<?php $__env->startSection('title', 'Grades'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">

        <div>
            <h2 class="mb-1">Grades</h2>

            <p class="text-muted mb-0">
                Every recorded grade. GPA is recalculated automatically.
            </p>
        </div>

        <a href="<?php echo e(route('grades.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i>
            Record Grade
        </a>

    </div>


    <!-- Filters -->
    <div class="card shadow-hover mb-4">

        <div class="card-header">
            <h5 class="mb-0">
                <i class="bi bi-funnel me-2"></i>
                Grade Filters
            </h5>
        </div>

        <div class="card-body">

            <form method="GET" action="<?php echo e(route('grades.index')); ?>">

                <div class="row g-3 align-items-end">

                    <div class="col-md-3">
                        <label for="student_id" class="form-label fw-semibold">Student</label>

                        <select name="student_id" id="student_id" class="form-select">
                            <option value="">All Students</option>

                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($student->id); ?>" <?php echo e(request('student_id') == $student->id ? 'selected' : ''); ?>>
                                    <?php echo e($student->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <label for="program" class="form-label fw-semibold">Program</label>

                        <select name="program" id="program" class="form-select">
                            <option value="">All Programs</option>

                            <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($program); ?>" <?php echo e(request('program') == $program ? 'selected' : ''); ?>>
                                    <?php echo e($program); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <label for="subject" class="form-label fw-semibold">Subject</label>

                        <select name="subject" id="subject" class="form-select">
                            <option value="">All Subjects</option>

                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($subject); ?>" <?php echo e(request('subject') == $subject ? 'selected' : ''); ?>>
                                    <?php echo e($subject); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <label for="term" class="form-label fw-semibold">Term</label>

                        <select name="term" id="term" class="form-select">
                            <option value="">All Terms</option>

                            <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value); ?>" <?php echo e(request('term') == $value ? 'selected' : ''); ?>>
                                    <?php echo e($label); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" name="result" value="failed" id="failedOnly" <?php echo e(request('result') === 'failed' ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="failedOnly">Failed grades only</label>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary flex-grow-1">
                                <i class="bi bi-search me-1"></i>
                                Apply
                            </button>

                            <a href="<?php echo e(route('grades.index')); ?>" class="btn btn-outline-secondary" title="Reset Filters">
                                <i class="bi bi-arrow-counterclockwise"></i>
                            </a>
                        </div>
                    </div>

                </div>

            </form>

        </div>

    </div>


    <!-- Grades Table -->
    <div class="card">

        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Grade List</h5>

            <span class="badge bg-secondary">
                <?php echo e($grades->total()); ?> grade(s)
            </span>
        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-striped table-hover align-middle">

                    <thead>
                        <tr>
                            <th>Date Recorded</th>
                            <th>Student</th>
                            <th>Subject</th>
                            <th>Term</th>
                            <th class="text-center">Units</th>
                            <th class="text-center">Grade</th>
                            <th>Recorded By</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php $__empty_1 = true; $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <tr>
                                <td><?php echo e($grade->created_at->format('M d, Y h:i A')); ?></td>

                                <td>
                                    <a href="<?php echo e(route('students.show', $grade->student_id)); ?>" class="text-decoration-none fw-semibold">
                                        <?php echo e($grade->student?->name); ?>

                                    </a>
                                    <small class="text-muted d-block"><?php echo e($grade->student?->student_id); ?></small>
                                </td>

                                <td><?php echo e($grade->subject); ?></td>

                                <td><?php echo e($grade->term_label); ?></td>

                                <td class="text-center"><?php echo e($grade->units); ?></td>

                                <td class="text-center">
                                    <span class="badge status-badge bg-<?php echo e($grade->grade_color); ?> <?php echo e($grade->grade_color === 'warning' ? 'text-dark' : ''); ?>">
                                        <?php echo e(number_format((float) $grade->grade, 2)); ?>

                                    </span>
                                </td>

                                <td><?php echo e($grade->user?->name ?? '—'); ?></td>

                                <td>
                                    <div class="d-flex gap-1">
                                        <a href="<?php echo e(route('grades.show', $grade)); ?>" class="btn btn-sm btn-outline-primary" title="View">
                                            <i class="bi bi-eye"></i>
                                        </a>

                                        <a href="<?php echo e(route('grades.edit', $grade)); ?>" class="btn btn-sm btn-outline-secondary" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </a>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                                            <form
                                                method="POST"
                                                action="<?php echo e(route('grades.destroy', $grade)); ?>"
                                                onsubmit="return confirm('Delete this grade? The GPA will be recalculated.');"
                                            >
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>

                                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <tr>
                                <td colspan="8" class="text-center text-muted py-4">
                                    <i class="bi bi-search fs-3 d-block mb-2"></i>
                                    No grades found matching your filters.
                                </td>
                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

            <?php echo e($grades->links()); ?>


        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lab1_2411600150\lab6_2411600150\resources\views/grades/index.blade.php ENDPATH**/ ?>