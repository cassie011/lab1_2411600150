<?php $__env->startSection('title', 'Grade Details'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">

        <div>
            <h2 class="mb-1"><?php echo e($grade->subject); ?> — <?php echo e($grade->term_label); ?></h2>
            <p class="text-muted mb-0">Recorded <?php echo e($grade->created_at->format('F d, Y h:i A')); ?></p>
        </div>

        <div class="d-flex gap-2">
            <a href="<?php echo e(route('grades.edit', $grade)); ?>" class="btn btn-secondary">
                Edit
            </a>

            <a href="<?php echo e(route('grades.index')); ?>" class="btn btn-outline-secondary">
                Back to list
            </a>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                <form
                    method="POST"
                    action="<?php echo e(route('grades.destroy', $grade)); ?>"
                    onsubmit="return confirm('Delete this grade? The GPA will be recalculated.');"
                >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <button type="submit" class="btn btn-outline-danger">
                        <i class="bi bi-trash me-1"></i>
                        Delete
                    </button>
                </form>
            <?php endif; ?>
        </div>

    </div>


    <div class="row">

        <!-- Grade Details -->
        <div class="col-lg-6 mb-4">
            <div class="card shadow-hover h-100">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-journal-text me-2"></i>Grade Details</h5>
                </div>

                <div class="card-body">
                    <table class="table mb-0">
                        <tr>
                            <th style="width: 170px;">Subject</th>
                            <td><?php echo e($grade->subject); ?></td>
                        </tr>
                        <tr>
                            <th>Term</th>
                            <td><?php echo e($grade->term_label); ?></td>
                        </tr>
                        <tr>
                            <th>Units</th>
                            <td><?php echo e($grade->units); ?></td>
                        </tr>
                        <tr>
                            <th>Grade</th>
                            <td>
                                <span class="badge bg-<?php echo e($grade->grade_color); ?> <?php echo e($grade->grade_color === 'warning' ? 'text-dark' : ''); ?> fs-6">
                                    <?php echo e(number_format((float) $grade->grade, 2)); ?>

                                </span>
                                <span class="ms-2 <?php echo e($grade->isPassing() ? 'value-good' : 'value-bad'); ?>"><?php echo e($grade->result); ?></span>
                            </td>
                        </tr>
                        <tr>
                            <th>Remarks</th>
                            <td><?php echo e($grade->remarks ?: '—'); ?></td>
                        </tr>
                        <tr>
                            <th>Last Updated</th>
                            <td><?php echo e($grade->updated_at->format('M d, Y h:i A')); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>


        <div class="col-lg-6">

            <!-- Student Information -->
            <div class="card shadow-hover mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-person-vcard me-2"></i>Student Information</h5>
                </div>

                <div class="card-body">
                    <h5 class="mb-1">
                        <a href="<?php echo e(route('students.show', $grade->student)); ?>" class="text-decoration-none">
                            <?php echo e($grade->student->name); ?>

                        </a>
                    </h5>

                    <p class="text-muted mb-3">
                        <?php echo e($grade->student->student_id); ?> — <?php echo e($grade->student->program); ?>, Year <?php echo e($grade->student->year_level); ?>

                    </p>

                    <div class="d-flex justify-content-between border-bottom py-2">
                        <span>Current GPA</span>
                        <strong><?php echo e(number_format((float) $grade->student->gpa, 2)); ?></strong>
                    </div>

                    <div class="d-flex justify-content-between border-bottom py-2">
                        <span>Attendance</span>
                        <strong><?php echo e($grade->student->attendance_rate); ?>%</strong>
                    </div>

                    <div class="d-flex justify-content-between py-2">
                        <span>Standing</span>
                        <span class="badge bg-<?php echo e($grade->student->standing_color); ?> <?php echo e($grade->student->standing_color === 'warning' ? 'text-dark' : ''); ?>">
                            <?php echo e($grade->student->academic_standing); ?>

                        </span>
                    </div>
                </div>
            </div>

            <!-- Teacher Information -->
            <div class="card shadow-hover mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-person-badge me-2"></i>Recorded By</h5>
                </div>

                <div class="card-body d-flex align-items-center gap-3">
                    <i class="bi bi-person-circle fs-1 text-primary-custom"></i>

                    <div>
                        <?php if($grade->user): ?>
                            <div class="fw-semibold"><?php echo e($grade->user->name); ?></div>
                            <small class="text-muted d-block"><?php echo e($grade->user->email); ?></small>
                            <span class="badge bg-light text-primary-custom border text-capitalize"><?php echo e($grade->user->role); ?></span>
                        <?php else: ?>
                            <span class="text-muted">User no longer exists</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lab1_2411600150\lab6_2411600150\resources\views/grades/show.blade.php ENDPATH**/ ?>