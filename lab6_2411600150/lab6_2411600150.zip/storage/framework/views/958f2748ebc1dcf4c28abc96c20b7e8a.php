<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <!-- Dashboard Header -->
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">

        <h2>
            <?php echo e($greeting); ?>, <?php echo e(auth()->user()->name); ?>!
        </h2>

    </div>


    <!-- Academic Warning Alert -->
    <?php if($stats['at_risk_count'] > 0): ?>

        <div
            id="atRiskAlert"
            class="alert alert-warning alert-dismissible fade show"
            role="alert"
        >

            <strong>Academic Alert:</strong>

            <?php echo e($stats['at_risk_count']); ?> student(s) are currently at risk.

            <button
                type="button"
                class="btn-close"
                data-bs-dismiss="alert"
                aria-label="Close"
            ></button>

        </div>

    <?php endif; ?>


    <!-- Statistics Cards -->
    <div class="row mb-4">

        <!-- Total Students -->
        <div class="col-md-3 mb-3">

            <div class="card stat-card shadow-hover text-center">

                <div class="card-body">

                    <h5 class="card-title text-muted">
                        Students
                    </h5>

                    <h2 class="card-text fw-bold text-primary-custom" id="statTotalStudents" data-value="<?php echo e($stats['total_students']); ?>">
                        <?php echo e($stats['total_students']); ?>

                    </h2>

                </div>

            </div>

        </div>


        <!-- Average GPA -->
        <div class="col-md-3 mb-3">

            <div class="card stat-card shadow-hover text-center">

                <div class="card-body">

                    <h5 class="card-title text-muted">
                        Average GPA
                    </h5>

                    <h2 class="card-text fw-bold text-primary-custom" id="statAverageGpa" data-value="<?php echo e($stats['average_gpa']); ?>" data-decimals="2">
                        <?php echo e(number_format($stats['average_gpa'], 2)); ?>

                    </h2>

                </div>

            </div>

        </div>


        <!-- At Risk -->
        <div class="col-md-3 mb-3">

            <div class="card stat-card shadow-hover text-center">

                <div class="card-body">

                    <h5 class="card-title text-muted">
                        At Risk
                    </h5>

                    <h2 class="card-text fw-bold text-warning" id="statAtRisk" data-value="<?php echo e($stats['at_risk_count']); ?>">
                        <?php echo e($stats['at_risk_count']); ?>

                    </h2>

                </div>

            </div>

        </div>


        <!-- Attendance -->
        <div class="col-md-3 mb-3">

            <div class="card stat-card shadow-hover text-center">

                <div class="card-body">

                    <h5 class="card-title text-muted">
                        Attendance
                    </h5>

                    <h2 class="card-text fw-bold text-success" id="statAverageAttendance" data-value="<?php echo e($stats['average_attendance']); ?>" data-decimals="1" data-suffix="%">
                        <?php echo e($stats['average_attendance']); ?>%
                    </h2>

                </div>

            </div>

        </div>

    </div>


    <!-- Charts -->
    <div class="row mb-4">

        <!-- Students by Program -->
        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow-hover h-100">

                <div class="card-header">

                    <h6 class="mb-0">
                        Enrolled Students by Program
                    </h6>

                </div>

                <div class="card-body">

                    <div class="chart-container">

                        <canvas
                            id="programValueChart"
                            aria-label="Enrolled students by program chart"
                            role="img"
                        ></canvas>

                    </div>

                </div>

            </div>

        </div>


        <!-- Academic Standing -->
        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow-hover h-100">

                <div class="card-header">

                    <h6 class="mb-0">
                        Academic Standing Distribution
                    </h6>

                </div>

                <div class="card-body">

                    <div class="chart-container">

                        <canvas
                            id="standingChart"
                            aria-label="Academic standing distribution chart"
                            role="img"
                        ></canvas>

                    </div>

                </div>

            </div>

        </div>


        <!-- Top Students -->
        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow-hover h-100">

                <div class="card-header">

                    <h6 class="mb-0">
                        Top Students by GPA
                    </h6>

                </div>

                <div class="card-body">

                    <div class="chart-container">

                        <canvas
                            id="topStudentsChart"
                            aria-label="Top students by GPA chart"
                            role="img"
                        ></canvas>

                    </div>

                </div>

            </div>

        </div>

        <!-- Attendance Rate -->
        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow-hover h-100">

                <div class="card-header">

                    <h6 class="mb-0">
                        Attendance Rate by Student
                    </h6>

                </div>

                <div class="card-body">

                    <div class="chart-container">

                        <canvas
                            id="attendanceChart"
                            aria-label="Attendance rate by student chart"
                            role="img"
                        ></canvas>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- ==========================================
         Lab 6: Real-Time Academic Tracking (AJAX polling)
    =========================================== -->
    <div
        id="academicLive"
        data-stats-url="<?php echo e(route('api.dashboard.stats')); ?>"
        data-at-risk-url="<?php echo e(route('api.students.atRisk')); ?>"
        data-recent-url="<?php echo e(route('api.activity.recent', ['limit' => 6])); ?>"
        data-interval="30000"
    >

        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 pb-2 mb-3 border-bottom">

            <h4 class="mb-0">
                <i class="bi bi-activity me-2 text-primary-custom"></i>
                Today's Activity
            </h4>

            <small class="text-muted">
                <span id="liveDot" class="live-dot"></span>
                Last Updated: <span id="lastUpdated"><?php echo e(now()->format('h:i:s A')); ?></span>
                <span id="liveError" class="text-danger ms-2 d-none">Connection problem. Retrying...</span>
            </small>

        </div>


        <!-- Today Statistics Cards -->
        <div class="row mb-4">

            <div class="col-md-3 col-6 mb-3">
                <div class="card stat-card shadow-hover text-center border-success-custom">
                    <div class="card-body">
                        <h5 class="card-title text-muted">Present Today</h5>
                        <h2 class="card-text fw-bold text-success" id="statPresentToday" data-value="<?php echo e($liveStats['present_today']); ?>">
                            <?php echo e($liveStats['present_today']); ?>

                        </h2>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-6 mb-3">
                <div class="card stat-card shadow-hover text-center border-accent">
                    <div class="card-body">
                        <h5 class="card-title text-muted">Absent Today</h5>
                        <h2 class="card-text fw-bold text-danger" id="statAbsentToday" data-value="<?php echo e($liveStats['absent_today']); ?>">
                            <?php echo e($liveStats['absent_today']); ?>

                        </h2>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-6 mb-3">
                <div class="card stat-card shadow-hover text-center border-primary-custom">
                    <div class="card-body">
                        <h5 class="card-title text-muted">Grades Recorded</h5>
                        <h2 class="card-text fw-bold text-primary-custom" id="statGradesToday" data-value="<?php echo e($liveStats['grades_today']); ?>">
                            <?php echo e($liveStats['grades_today']); ?>

                        </h2>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-6 mb-3">
                <div class="card stat-card shadow-hover text-center border-accent">
                    <div class="card-body">
                        <h5 class="card-title text-muted">Need Attention</h5>
                        <h2 class="card-text fw-bold text-warning" id="statNeedsAttention" data-value="<?php echo e($liveStats['needs_attention_count']); ?>">
                            <?php echo e($liveStats['needs_attention_count']); ?>

                        </h2>
                    </div>
                </div>
            </div>

        </div>


        <div class="row mb-4">

            <!-- Academic Alerts -->
            <div class="col-lg-5 mb-3">
                <div class="card shadow-hover h-100">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h6 class="mb-0">
                            <i class="bi bi-exclamation-triangle text-warning me-1"></i>
                            Students Needing Attention
                        </h6>

                        <a href="<?php echo e(route('reports.index', ['report' => 'at_risk'])); ?>" class="small text-decoration-none">
                            View report
                        </a>
                    </div>

                    <div class="card-body p-0">
                        <ul class="list-group list-group-flush" id="atRiskList">
                            <?php $__empty_1 = true; $__currentLoopData = $attentionStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <a href="<?php echo e(route('students.show', $s)); ?>" class="text-decoration-none fw-semibold"><?php echo e($s->name); ?></a>
                                        <small class="text-muted d-block"><?php echo e(implode('; ', $s->alert_reasons)); ?></small>
                                    </div>
                                    <span class="badge bg-<?php echo e($s->standing_color); ?> <?php echo e($s->standing_color === 'warning' ? 'text-dark' : ''); ?>">
                                        <?php echo e(number_format((float) $s->gpa, 2)); ?> · <?php echo e($s->attendance_rate); ?>%
                                    </span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="list-group-item text-center text-muted py-4">
                                    All students are in good standing.
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>


            <!-- Recent Activity -->
            <div class="col-lg-7 mb-3">
                <div class="card shadow-hover h-100">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h6 class="mb-0">
                            <i class="bi bi-clock-history me-1"></i>
                            Recent Grades & Attendance
                        </h6>

                        <a href="<?php echo e(route('grades.index')); ?>" class="small text-decoration-none">
                            View grades
                        </a>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm table-hover align-middle mb-0">
                                <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Student</th>
                                        <th>Type</th>
                                        <th>Details</th>
                                        <th>By</th>
                                    </tr>
                                </thead>

                                <tbody id="recentActivityBody">
                                    <?php $__empty_1 = true; $__currentLoopData = $recentActivity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php $isGrade = $item instanceof \App\Models\Grade; ?>
                                        <tr>
                                            <td><small><?php echo e($item->created_at->diffForHumans()); ?></small></td>
                                            <td>
                                                <a href="<?php echo e(route('students.show', $item->student_id)); ?>" class="text-decoration-none">
                                                    <?php echo e($item->student?->name); ?>

                                                </a>
                                            </td>
                                            <td>
                                                <span class="badge status-badge bg-<?php echo e($isGrade ? $item->grade_color : $item->status_color); ?> <?php echo e(($isGrade ? $item->grade_color : $item->status_color) === 'warning' ? 'text-dark' : ''); ?>">
                                                    <?php echo e($isGrade ? 'Grade' : 'Attendance'); ?>

                                                </span>
                                            </td>
                                            <td><small>
                                                <?php if($isGrade): ?>
                                                    <?php echo e($item->subject); ?> (<?php echo e($item->term_label); ?>): <?php echo e(number_format((float) $item->grade, 2)); ?>

                                                <?php else: ?>
                                                    <?php echo e($item->status_label); ?> on <?php echo e($item->date->format('M d')); ?>

                                                <?php endif; ?>
                                            </small></td>
                                            <td><small><?php echo e($item->user?->name ?? '—'); ?></small></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="5" class="text-center text-muted py-3">No activity yet.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>


    <!-- Student Roster -->
    <div class="card mb-4">

        <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">

            <h5 class="mb-0">
                Students List
            </h5>

            <a
                href="<?php echo e(route('students.create')); ?>"
                class="btn btn-primary btn-sm"
            >
                + Add Student
            </a>

        </div>


        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-striped table-hover align-middle">

                    <thead>

                        <tr class="border-accent">

                            <th>Student ID</th>
                            <th>Name</th>
                            <th>Program</th>
                            <th>Year</th>
                            <th>Units</th>
                            <th>GPA</th>
                            <th>Attendance</th>
                            <th>Status</th>

                        </tr>

                    </thead>


                    <tbody>

                        <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <tr>

                                <td>
                                    <?php echo e($student->student_id); ?>

                                </td>

                                <td>
                                    <?php echo e($student->name); ?>

                                </td>

                                <td>
                                    <?php echo e($student->program); ?>

                                </td>

                                <td>
                                    <?php echo e($student->year_level); ?>

                                </td>

                                <td>
                                    <?php echo e($student->units); ?>

                                </td>

                                <td>
                                    <?php echo e(number_format($student->gpa, 2)); ?>

                                </td>

                                <td>
                                    <?php echo e($student->attendance_rate); ?>%
                                </td>

                                <td>

                                    <?php

                                        $badgeClass = match($student->academic_standing) {

                                            'Good Standing' => 'bg-success',

                                            'At Risk' => 'bg-warning text-dark',

                                            default => 'bg-danger',

                                        };

                                    ?>


                                    <span class="badge status-badge <?php echo e($badgeClass); ?>">

                                        <?php echo e($student->academic_standing); ?>


                                    </span>

                                </td>

                            </tr>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <tr>

                                <td
                                    colspan="8"
                                    class="text-center text-muted"
                                >

                                    No students available.

                                </td>

                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>


    <!-- Students by Program -->
    <div class="card mb-4">

        <div class="card-header">

            <h5 class="mb-0">
                Students by Program
            </h5>

        </div>


        <div class="card-body">

            <?php $__empty_1 = true; $__currentLoopData = $byProgram; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <div class="d-flex justify-content-between border-bottom py-2">

                    <span>
                        <?php echo e($program); ?>

                    </span>

                    <strong>
                        <?php echo e($count); ?>

                    </strong>

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <p class="text-muted mb-0">
                    No program data available.
                </p>

            <?php endif; ?>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>

<script>

    // ==========================================
    // Students by Program
    // ==========================================

    const programLabels = <?php echo json_encode($byProgram->keys(), 15, 512) ?>;

    const programData = <?php echo json_encode($byProgram->values(), 15, 512) ?>;


    new Chart(document.getElementById('programValueChart'), {

        type: 'bar',

        data: {

            labels: programLabels,

            datasets: [{

                label: 'Students',

                data: programData

            }]

        },

        options: {

            responsive: true,

            maintainAspectRatio: false

        }

    });


    // ==========================================
    // Academic Standing
    // ==========================================

    const standingData = {

        'Good Standing': 0,

        'At Risk': 0,

        'Probation': 0

    };


    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        standingData['<?php echo e($student->academic_standing); ?>']++;

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    new Chart(document.getElementById('standingChart'), {

        type: 'doughnut',

        data: {

            labels: Object.keys(standingData),

            datasets: [{

                data: Object.values(standingData)

            }]

        },

        options: {

            responsive: true,

            maintainAspectRatio: false

        }

    });


    // ==========================================
    // Top Students by GPA
    // ==========================================

    const topStudentLabels = <?php echo json_encode($topStudents->pluck('name'), 15, 512) ?>;

    const topStudentGpa = <?php echo json_encode($topStudents->pluck('gpa'), 15, 512) ?>;


    new Chart(document.getElementById('topStudentsChart'), {

        type: 'bar',

        data: {

            labels: topStudentLabels,

            datasets: [{

                label: 'GPA',

                data: topStudentGpa

            }]

        },

        options: {

            indexAxis: 'y',

            responsive: true,

            maintainAspectRatio: false,

            scales: {

                x: {

                    min: 0,

                    max: 4

                }

            }

        }

    });

</script>

<script>

    // ==========================================
    // Attendance Rate by Student
    // ==========================================

    const attendanceLabels = <?php echo json_encode($students->pluck('name')->values(), 15, 512) ?>;

    const attendanceData = <?php echo json_encode($students->pluck('attendance_rate')->values(), 15, 512) ?>;


    new Chart(document.getElementById('attendanceChart'), {

        type: 'bar',

        data: {

            labels: attendanceLabels,

            datasets: [{

                label: 'Attendance %',

                data: attendanceData

            }]

        },

        options: {

            responsive: true,

            maintainAspectRatio: false,

            scales: {

                y: {

                    min: 0,

                    max: 100

                }

            }

        }

    });

</script>

<!-- Lab 6: real-time academic polling -->
<script src="<?php echo e(asset('js/academic-dashboard.js')); ?>"></script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lab1_2411600150\lab6_2411600150\resources\views/dashboard.blade.php ENDPATH**/ ?>