<tr>
<td>
<table class="footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td class="content-cell" align="center">
<?php echo new \Illuminate\Support\EncodedHtmlString(Illuminate\Mail\Markdown::parse($slot)); ?>

</td>
</tr>
</table>
</td>
</tr>
<?php /**PATH C:\xampp\htdocs\lab1_2411600150\lab6_2411600150\vendor\laravel\framework\src\Illuminate\Mail/resources/views/html/footer.blade.php ENDPATH**/ ?>