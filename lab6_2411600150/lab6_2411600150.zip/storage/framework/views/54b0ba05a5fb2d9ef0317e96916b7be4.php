<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\lab1_2411600150\lab6_2411600150\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>