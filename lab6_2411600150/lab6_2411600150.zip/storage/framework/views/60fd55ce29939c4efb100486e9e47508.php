<?php $__env->startSection('title', 'Take Attendance'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
            <h2 class="mb-1">Take Attendance</h2>
            <p class="text-muted mb-0">
                Pick a class and date. Saved records for that date load automatically, so you can also correct them here.
            </p>
        </div>

        <a href="<?php echo e(route('attendance.index')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-list-check me-1"></i>
            Attendance Records
        </a>
    </div>


    <!-- Class Picker -->
    <div class="card shadow-hover mb-4">

        <div class="card-header">
            <h5 class="mb-0">
                <i class="bi bi-people me-2"></i>
                Select Class
            </h5>
        </div>

        <div class="card-body">

            <form method="GET" action="<?php echo e(route('attendance.create')); ?>">

                <div class="row g-3 align-items-end">

                    <div class="col-md-4">
                        <label for="program" class="form-label fw-semibold">Program</label>

                        <select name="program" id="program" class="form-select" required>
                            <option value="">-- Select program --</option>

                            <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($program); ?>" <?php echo e(request('program') == $program ? 'selected' : ''); ?>>
                                    <?php echo e($program); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <label for="year_level" class="form-label fw-semibold">Year Level</label>

                        <select name="year_level" id="year_level" class="form-select">
                            <option value="">All</option>

                            <?php for($y = 1; $y <= 4; $y++): ?>
                                <option value="<?php echo e($y); ?>" <?php echo e(request('year_level') == $y ? 'selected' : ''); ?>>Year <?php echo e($y); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <label for="date" class="form-label fw-semibold">Date</label>

                        <input
                            type="date"
                            name="date"
                            id="date"
                            class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e($date); ?>"
                            max="<?php echo e(now()->toDateString()); ?>"
                            required
                        >

                        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger small"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-md-3">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-search me-1"></i>
                            Load Class
                        </button>
                    </div>

                </div>

            </form>

        </div>

    </div>


    <?php if(request()->filled('program')): ?>

        <!-- Class List -->
        <form method="POST" action="<?php echo e(route('attendance.store')); ?>">
            <?php echo csrf_field(); ?>

            <input type="hidden" name="date" value="<?php echo e($date); ?>">
            <input type="hidden" name="program" value="<?php echo e(request('program')); ?>">
            <input type="hidden" name="year_level" value="<?php echo e(request('year_level')); ?>">

            <div class="card">

                <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">

                    <h5 class="mb-0">
                        <?php echo e(request('program')); ?>

                        <?php if(request('year_level')): ?> — Year <?php echo e(request('year_level')); ?> <?php endif; ?>
                        <small class="text-muted fs-6">· <?php echo e(\Illuminate\Support\Carbon::parse($date)->format('l, M d, Y')); ?></small>
                    </h5>

                    <?php if($students->isNotEmpty()): ?>
                        <div class="d-flex gap-2">
                            <button type="button" class="btn btn-sm btn-outline-success" onclick="markAll('present')">
                                All Present
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-danger" onclick="markAll('absent')">
                                All Absent
                            </button>
                        </div>
                    <?php endif; ?>

                </div>

                <div class="card-body">

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger py-2"><?php echo e($errors->first()); ?></div>
                    <?php endif; ?>

                    <div class="table-responsive">

                        <table class="table table-hover align-middle attendance-table">

                            <thead>
                                <tr>
                                    <th>Student ID</th>
                                    <th>Name</th>
                                    <th class="text-center">Current Rate</th>
                                    <th>Status</th>
                                    <th>Remarks</th>
                                </tr>
                            </thead>

                            <tbody>

                                <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                    <?php
                                        $current = old("attendance.{$student->id}.status", $existing[$student->id]->status ?? 'present');
                                    ?>

                                    <tr>
                                        <td><?php echo e($student->student_id); ?></td>

                                        <td>
                                            <?php echo e($student->name); ?>

                                            <?php if(isset($existing[$student->id])): ?>
                                                <span class="badge bg-light text-muted border ms-1">saved</span>
                                            <?php endif; ?>
                                        </td>

                                        <td class="text-center <?php echo e($student->hasLowAttendance() ? 'value-bad' : ''); ?>">
                                            <?php echo e($student->attendance_rate); ?>%
                                        </td>

                                        <td>
                                            <div class="btn-group btn-group-sm" role="group" aria-label="Status for <?php echo e($student->name); ?>">
                                                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $color = match ($value) {
                                                            'present' => 'success',
                                                            'late' => 'warning',
                                                            'excused' => 'info',
                                                            default => 'danger',
                                                        };
                                                    ?>

                                                    <input
                                                        type="radio"
                                                        class="btn-check status-radio"
                                                        name="attendance[<?php echo e($student->id); ?>][status]"
                                                        id="status_<?php echo e($student->id); ?>_<?php echo e($value); ?>"
                                                        value="<?php echo e($value); ?>"
                                                        autocomplete="off"
                                                        <?php echo e($current === $value ? 'checked' : ''); ?>

                                                    >
                                                    <label class="btn btn-outline-<?php echo e($color); ?>" for="status_<?php echo e($student->id); ?>_<?php echo e($value); ?>">
                                                        <?php echo e($label); ?>

                                                    </label>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </td>

                                        <td>
                                            <input
                                                type="text"
                                                name="attendance[<?php echo e($student->id); ?>][remarks]"
                                                class="form-control form-control-sm"
                                                maxlength="255"
                                                value="<?php echo e(old("attendance.{$student->id}.remarks", $existing[$student->id]->remarks ?? '')); ?>"
                                                placeholder="Optional"
                                            >
                                        </td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                    <tr>
                                        <td colspan="5" class="text-center text-muted py-4">
                                            No students in this class.
                                        </td>
                                    </tr>

                                <?php endif; ?>

                            </tbody>

                        </table>

                    </div>

                    <?php if($students->isNotEmpty()): ?>
                        <button type="submit" class="btn btn-primary mt-2">
                            <i class="bi bi-check2-circle me-1"></i>
                            Save Attendance
                        </button>
                    <?php endif; ?>

                </div>

            </div>

        </form>

    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script>
    // Set the same status for every student in the list
    function markAll(status) {
        document.querySelectorAll('.status-radio[value="' + status + '"]').forEach(function (radio) {
            radio.checked = true;
        });
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lab1_2411600150\lab6_2411600150\resources\views/attendance/create.blade.php ENDPATH**/ ?>