<?php $__env->startSection('title', 'Attendance Records'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">

        <div>
            <h2 class="mb-1">Attendance Records</h2>
            <p class="text-muted mb-0">Every attendance entry and who recorded it</p>
        </div>

        <a href="<?php echo e(route('attendance.create')); ?>" class="btn btn-primary">
            <i class="bi bi-calendar-check me-1"></i>
            Take Attendance
        </a>

    </div>


    <!-- Filters -->
    <div class="card shadow-hover mb-4">

        <div class="card-header">
            <h5 class="mb-0">
                <i class="bi bi-funnel me-2"></i>
                Attendance Filters
            </h5>
        </div>

        <div class="card-body">

            <form method="GET" action="<?php echo e(route('attendance.index')); ?>">

                <div class="row g-3 align-items-end">

                    <div class="col-md-3">
                        <label for="student_id" class="form-label fw-semibold">Student</label>

                        <select name="student_id" id="student_id" class="form-select">
                            <option value="">All Students</option>

                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($student->id); ?>" <?php echo e(request('student_id') == $student->id ? 'selected' : ''); ?>>
                                    <?php echo e($student->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <label for="program" class="form-label fw-semibold">Program</label>

                        <select name="program" id="program" class="form-select">
                            <option value="">All</option>

                            <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($program); ?>" <?php echo e(request('program') == $program ? 'selected' : ''); ?>>
                                    <?php echo e($program); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <label for="status" class="form-label fw-semibold">Status</label>

                        <select name="status" id="status" class="form-select">
                            <option value="">All</option>

                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value); ?>" <?php echo e(request('status') == $value ? 'selected' : ''); ?>>
                                    <?php echo e($label); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <label for="date_from" class="form-label fw-semibold">From</label>
                        <input type="date" name="date_from" id="date_from" class="form-control" value="<?php echo e(request('date_from')); ?>">
                    </div>

                    <div class="col-md-2">
                        <label for="date_to" class="form-label fw-semibold">To</label>
                        <input type="date" name="date_to" id="date_to" class="form-control" value="<?php echo e(request('date_to')); ?>">
                    </div>

                    <div class="col-md-1">
                        <div class="d-flex gap-1">
                            <button type="submit" class="btn btn-primary flex-grow-1" title="Apply">
                                <i class="bi bi-search"></i>
                            </button>

                            <a href="<?php echo e(route('attendance.index')); ?>" class="btn btn-outline-secondary" title="Reset Filters">
                                <i class="bi bi-arrow-counterclockwise"></i>
                            </a>
                        </div>
                    </div>

                </div>

                <?php if($errors->any()): ?>
                    <div class="text-danger small mt-2"><?php echo e($errors->first()); ?></div>
                <?php endif; ?>

            </form>

        </div>

    </div>


    <!-- Records Table -->
    <div class="card">

        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Attendance List</h5>

            <span class="badge bg-secondary">
                <?php echo e($records->total()); ?> record(s)
            </span>
        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-striped table-hover align-middle">

                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Student</th>
                            <th>Program</th>
                            <th>Status</th>
                            <th>Remarks</th>
                            <th>Recorded By</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <tr>
                                <td><?php echo e($record->date->format('M d, Y')); ?></td>

                                <td>
                                    <a href="<?php echo e(route('students.show', $record->student_id)); ?>" class="text-decoration-none fw-semibold">
                                        <?php echo e($record->student?->name); ?>

                                    </a>
                                    <small class="text-muted d-block"><?php echo e($record->student?->student_id); ?></small>
                                </td>

                                <td><?php echo e($record->student?->program); ?></td>

                                <td>
                                    <span class="badge status-badge bg-<?php echo e($record->status_color); ?> <?php echo e($record->status_color === 'warning' ? 'text-dark' : ''); ?>">
                                        <?php echo e($record->status_label); ?>

                                    </span>
                                </td>

                                <td><?php echo e($record->remarks ?: '—'); ?></td>

                                <td><?php echo e($record->user?->name ?? '—'); ?></td>

                                <td>
                                    <div class="d-flex gap-1">
                                        <a
                                            href="<?php echo e(route('attendance.create', ['program' => $record->student?->program, 'date' => $record->date->toDateString()])); ?>"
                                            class="btn btn-sm btn-outline-secondary"
                                            title="Edit this day"
                                        >
                                            <i class="bi bi-pencil"></i>
                                        </a>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                                            <form
                                                method="POST"
                                                action="<?php echo e(route('attendance.destroy', $record)); ?>"
                                                onsubmit="return confirm('Delete this attendance record? The attendance rate will be recalculated.');"
                                            >
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>

                                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <tr>
                                <td colspan="7" class="text-center text-muted py-4">
                                    <i class="bi bi-search fs-3 d-block mb-2"></i>
                                    No attendance records found matching your filters.
                                </td>
                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

            <?php echo e($records->links()); ?>


        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lab1_2411600150\lab6_2411600150\resources\views/attendance/index.blade.php ENDPATH**/ ?>