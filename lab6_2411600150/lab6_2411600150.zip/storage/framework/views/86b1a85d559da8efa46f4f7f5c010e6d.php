

<div class="row">

    <!-- Student (searchable) -->
    <div class="col-md-7 mb-3">

        <label for="student_id" class="form-label fw-semibold">Student</label>

        <input
            type="text"
            id="studentSearch"
            class="form-control form-control-sm mb-2"
            placeholder="Type to search by name or Student ID..."
            autocomplete="off"
        >

        <select
            name="student_id"
            id="student_id"
            class="form-select <?php $__errorArgs = ['student_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            required
        >
            <option value="">-- Select student --</option>

            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option
                    value="<?php echo e($student->id); ?>"
                    data-search="<?php echo e(strtolower($student->name . ' ' . $student->student_id)); ?>"
                    <?php echo e(old('student_id', $selectedStudent) == $student->id ? 'selected' : ''); ?>

                >
                    <?php echo e($student->name); ?> (<?php echo e($student->student_id); ?>)
                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <?php $__errorArgs = ['student_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>


    <!-- Current GPA (loaded with AJAX) -->
    <div class="col-md-5 mb-3">
        <label class="form-label fw-semibold">Current Standing</label>

        <div id="studentInfo" class="info-box p-3">
            <span class="text-muted">Select a student to see their GPA.</span>
        </div>
    </div>

</div>


<div class="row">

    <!-- Subject -->
    <div class="col-md-6 mb-3">
        <label for="subject" class="form-label fw-semibold">Subject</label>

        <input
            type="text"
            name="subject"
            id="subject"
            list="subjectList"
            class="form-control <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            value="<?php echo e(old('subject', $grade->subject ?? '')); ?>"
            placeholder="e.g. Programming 2"
            maxlength="100"
            required
        >

        <datalist id="subjectList">
            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($subject); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </datalist>

        <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Units -->
    <div class="col-md-2 mb-3">
        <label for="units" class="form-label fw-semibold">Units</label>

        <input
            type="number"
            name="units"
            id="units"
            min="1"
            max="6"
            class="form-control <?php $__errorArgs = ['units'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            value="<?php echo e(old('units', $grade->units ?? 3)); ?>"
            required
        >

        <?php $__errorArgs = ['units'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Term -->
    <div class="col-md-4 mb-3">
        <label class="form-label fw-semibold d-block">Term</label>

        <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-check form-check-inline">
                <input
                    class="form-check-input"
                    type="radio"
                    name="term"
                    id="term_<?php echo e($value); ?>"
                    value="<?php echo e($value); ?>"
                    <?php echo e(old('term', $grade->term ?? 'prelim') == $value ? 'checked' : ''); ?>

                    required
                >
                <label class="form-check-label" for="term_<?php echo e($value); ?>"><?php echo e($label); ?></label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__errorArgs = ['term'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

</div>


<div class="row">

    <!-- Grade -->
    <div class="col-md-4 mb-3">
        <label for="grade" class="form-label fw-semibold">Grade (0.00 – 4.00)</label>

        <input
            type="number"
            step="0.01"
            min="0"
            max="4"
            name="grade"
            id="grade"
            class="form-control <?php $__errorArgs = ['grade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            value="<?php echo e(old('grade', isset($grade) ? number_format((float) $grade->grade, 2) : '')); ?>"
            required
        >

        <div class="form-text" id="gradeHelp">3.00 and above = Good Standing. Below 1.00 = Failed.</div>

        <?php $__errorArgs = ['grade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Remarks -->
    <div class="col-md-8 mb-3">
        <label for="remarks" class="form-label fw-semibold">Remarks</label>

        <textarea
            name="remarks"
            id="remarks"
            rows="2"
            maxlength="500"
            class="form-control <?php $__errorArgs = ['remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
        ><?php echo e(old('remarks', $grade->remarks ?? '')); ?></textarea>

        <?php $__errorArgs = ['remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

</div>


<?php $__env->startPush('scripts'); ?>
<script>
    (function () {
        const select = document.getElementById('student_id');
        const search = document.getElementById('studentSearch');
        const info = document.getElementById('studentInfo');
        const summaryUrl = <?php echo json_encode(route('api.students.summary', ['student' => '__ID__']), 512) ?>;

        // Searchable dropdown: hide options that do not match
        search.addEventListener('input', function () {
            const term = this.value.trim().toLowerCase();
            let firstMatch = null;

            Array.from(select.options).forEach(function (option) {
                if (!option.value) return;
                const match = option.dataset.search.includes(term);
                option.hidden = !match;
                if (match && !firstMatch) firstMatch = option;
            });

            const current = select.selectedOptions[0];

            if (term && firstMatch && (!current || !current.value || current.hidden)) {
                select.value = firstMatch.value;
                loadSummary();
            }
        });

        // Show the student's current GPA, attendance and standing
        function loadSummary() {
            if (!select.value) {
                info.innerHTML = '<span class="text-muted">Select a student to see their GPA.</span>';
                return;
            }

            info.innerHTML = '<span class="text-muted"><span class="spinner-border spinner-border-sm me-1"></span> Loading...</span>';

            fetch(summaryUrl.replace('__ID__', select.value), { headers: { 'Accept': 'application/json' } })
                .then(function (response) {
                    if (!response.ok) throw new Error('Request failed');
                    return response.json();
                })
                .then(function (json) {
                    const s = json.data;
                    const dark = s.standing_color === 'warning' ? ' text-dark' : '';

                    info.innerHTML =
                        '<div class="d-flex justify-content-between align-items-center">' +
                            '<div><div class="fs-4 fw-bold text-primary-custom">GPA ' + s.gpa.toFixed(2) + '</div>' +
                            '<small class="text-muted">' + s.program + ' · Attendance ' + s.attendance_rate + '%</small></div>' +
                            '<span class="badge bg-' + s.standing_color + dark + '">' + s.academic_standing + '</span>' +
                        '</div>';
                })
                .catch(function () {
                    info.innerHTML = '<span class="text-danger">Could not load the student. Please try again.</span>';
                });
        }

        select.addEventListener('change', loadSummary);

        if (select.value) loadSummary();
    })();
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\lab1_2411600150\lab6_2411600150\resources\views/grades/_form.blade.php ENDPATH**/ ?>