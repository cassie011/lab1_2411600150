<?php $__env->startSection('title', $student->name); ?>

<?php $__env->startSection('content'); ?>

<div class="bg-white p-4 rounded shadow-sm mb-4">

    <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">

        <div>
            <h2><?php echo e($student->name); ?></h2>

            <p class="text-muted">
                <?php echo e($student->student_id); ?> — <?php echo e($student->program); ?>

                <?php if($student->user): ?>
                    <span class="badge bg-light text-primary-custom border ms-1">
                        <i class="bi bi-person-check me-1"></i>Has portal account
                    </span>
                <?php endif; ?>
            </p>
        </div>

        <div class="d-flex gap-2 flex-wrap">
            <a href="<?php echo e(route('grades.create', ['student_id' => $student->id])); ?>" class="btn btn-primary">
                <i class="bi bi-journal-plus me-1"></i>
                Record Grade
            </a>

            <a href="<?php echo e(route('attendance.create', ['program' => $student->program, 'year_level' => $student->year_level])); ?>" class="btn btn-outline-secondary">
                <i class="bi bi-calendar-check me-1"></i>
                Take Attendance
            </a>
        </div>

    </div>

    <?php if($student->needsAttention()): ?>
        <div class="alert alert-warning py-2">
            <i class="bi bi-exclamation-triangle me-1"></i>
            <strong>Needs attention:</strong> <?php echo e(implode('; ', $student->alert_reasons)); ?>.
        </div>
    <?php endif; ?>

    <table class="table w-50">

        <tr>
            <th>Year Level</th>
            <td><?php echo e($student->year_level); ?></td>
        </tr>

        <tr>
            <th>Units</th>
            <td><?php echo e($student->units); ?></td>
        </tr>

        <tr>
            <th>GPA</th>
            <td><?php echo e(number_format($student->gpa, 2)); ?></td>
        </tr>

        <tr>
            <th>Quality Points</th>
            <td><?php echo e($student->quality_points); ?></td>
        </tr>

        <tr>
            <th>Attendance</th>
            <td><?php echo e($student->attendance_rate); ?>%</td>
        </tr>

        <tr>
            <th>Standing</th>
            <td><?php echo e($student->academic_standing); ?></td>
        </tr>

    </table>

    <a
        href="<?php echo e(route('students.edit', $student)); ?>"
        class="btn btn-secondary"
    >
        Edit
    </a>

    <a
        href="<?php echo e(route('students.index')); ?>"
        class="btn btn-outline-secondary"
    >
        Back to list
    </a>

</div>


<!-- Grades (Lab 6) -->
<div class="card mb-4">

    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">
            <i class="bi bi-journal-text me-2"></i>
            Grades
        </h5>

        <span class="badge bg-secondary"><?php echo e($grades->count()); ?> grade(s)</span>
    </div>

    <div class="card-body">

        <div class="table-responsive">

            <table class="table table-striped table-hover align-middle">

                <thead>
                    <tr>
                        <th>Subject</th>
                        <th>Term</th>
                        <th class="text-center">Units</th>
                        <th class="text-center">Grade</th>
                        <th>Result</th>
                        <th>Recorded By</th>
                        <th></th>
                    </tr>
                </thead>

                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr>
                            <td><?php echo e($grade->subject); ?></td>
                            <td><?php echo e($grade->term_label); ?></td>
                            <td class="text-center"><?php echo e($grade->units); ?></td>
                            <td class="text-center">
                                <span class="badge status-badge bg-<?php echo e($grade->grade_color); ?> <?php echo e($grade->grade_color === 'warning' ? 'text-dark' : ''); ?>">
                                    <?php echo e(number_format((float) $grade->grade, 2)); ?>

                                </span>
                            </td>
                            <td class="<?php echo e($grade->isPassing() ? 'value-good' : 'value-bad'); ?>"><?php echo e($grade->result); ?></td>
                            <td><?php echo e($grade->user?->name ?? '—'); ?></td>
                            <td>
                                <a href="<?php echo e(route('grades.edit', $grade)); ?>" class="btn btn-sm btn-outline-secondary" title="Edit">
                                    <i class="bi bi-pencil"></i>
                                </a>
                            </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">No grades recorded yet.</td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>


<!-- Attendance History (Lab 6) -->
<div class="card mb-4">

    <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">

        <h5 class="mb-0">
            <i class="bi bi-clock-history me-2"></i>
            Attendance History
        </h5>

        <form method="GET" action="<?php echo e(route('students.show', $student)); ?>" class="d-flex gap-2 align-items-center flex-wrap">

            <input type="date" name="date_from" class="form-control form-control-sm w-auto" value="<?php echo e(request('date_from')); ?>" aria-label="Date from">

            <span class="text-muted small">to</span>

            <input type="date" name="date_to" class="form-control form-control-sm w-auto" value="<?php echo e(request('date_to')); ?>" aria-label="Date to">

            <button type="submit" class="btn btn-primary btn-sm">
                <i class="bi bi-funnel"></i>
            </button>

            <a href="<?php echo e(route('students.show', $student)); ?>" class="btn btn-outline-secondary btn-sm" title="Reset">
                <i class="bi bi-arrow-counterclockwise"></i>
            </a>

        </form>

    </div>

    <div class="card-body">

        <?php if($errors->any()): ?>
            <div class="alert alert-danger py-2"><?php echo e($errors->first()); ?></div>
        <?php endif; ?>

        <div class="table-responsive">

            <table class="table table-striped table-hover align-middle">

                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Status</th>
                        <th class="text-end">Running Rate</th>
                        <th>Remarks</th>
                        <th>Recorded By</th>
                    </tr>
                </thead>

                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr>
                            <td><?php echo e($record->date->format('D, M d, Y')); ?></td>
                            <td>
                                <span class="badge status-badge bg-<?php echo e($record->status_color); ?> <?php echo e($record->status_color === 'warning' ? 'text-dark' : ''); ?>">
                                    <?php echo e($record->status_label); ?>

                                </span>
                            </td>
                            <td class="text-end fw-semibold <?php echo e(($record->running_rate ?? 100) < \App\Models\Student::ATTENDANCE_THRESHOLD ? 'value-bad' : ''); ?>">
                                <?php echo e($record->running_rate !== null ? $record->running_rate . '%' : '—'); ?>

                            </td>
                            <td><?php echo e($record->remarks ?: '—'); ?></td>
                            <td><?php echo e($record->user?->name ?? '—'); ?></td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>
                            <td colspan="5" class="text-center text-muted py-4">No attendance records for this period.</td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lab1_2411600150\lab6_2411600150\resources\views/students/show.blade.php ENDPATH**/ ?>