<?php $__env->startSection('title', 'Academic Reports'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">

        <div>
            <h2 class="mb-1">Academic Reports</h2>
            <p class="text-muted mb-0">Generated <?php echo e(now()->format('M d, Y h:i A')); ?></p>
        </div>

        <a
            href="<?php echo e(route('reports.index', array_merge(request()->query(), ['report' => $report, 'export' => 'csv']))); ?>"
            class="btn btn-primary"
        >
            <i class="bi bi-download me-1"></i>
            Export CSV
        </a>

    </div>


    <!-- Report Tabs -->
    <ul class="nav nav-pills report-tabs mb-4 gap-2">
        <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e($report === $key ? 'active' : ''); ?>" href="<?php echo e(route('reports.index', ['report' => $key])); ?>">
                    <?php echo e($label); ?>

                </a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>


    <!-- Report Filters -->
    <div class="card shadow-hover mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('reports.index')); ?>">
                <input type="hidden" name="report" value="<?php echo e($report); ?>">

                <div class="row g-3 align-items-end">

                    <div class="col-md-3">
                        <label for="program" class="form-label fw-semibold">Program</label>
                        <select name="program" id="program" class="form-select">
                            <option value="">All Programs</option>
                            <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($p); ?>" <?php echo e($program == $p ? 'selected' : ''); ?>><?php echo e($p); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <?php if($report === 'attendance'): ?>
                        <div class="col-md-3">
                            <label for="date_from" class="form-label fw-semibold">From</label>
                            <input type="date" name="date_from" id="date_from" class="form-control" value="<?php echo e($dateFrom); ?>">
                        </div>

                        <div class="col-md-3">
                            <label for="date_to" class="form-label fw-semibold">To</label>
                            <input type="date" name="date_to" id="date_to" class="form-control" value="<?php echo e($dateTo); ?>">
                        </div>
                    <?php elseif($report === 'grades'): ?>
                        <div class="col-md-3">
                            <label for="term" class="form-label fw-semibold">Term</label>
                            <select name="term" id="term" class="form-select">
                                <option value="">All Terms</option>
                                <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value); ?>" <?php echo e($term == $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php endif; ?>

                    <div class="col-md-3">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-funnel me-1"></i>
                            Generate
                        </button>
                    </div>

                </div>

                <?php if($errors->any()): ?>
                    <div class="text-danger small mt-2"><?php echo e($errors->first()); ?></div>
                <?php endif; ?>
            </form>
        </div>
    </div>


    <?php if($report === 'attendance'): ?>

        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Attendance Summary (<?php echo e($dateFrom); ?> to <?php echo e($dateTo); ?>)</h5>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>Program</th>
                                <th class="text-center">Present</th>
                                <th class="text-center">Late</th>
                                <th class="text-center">Absent</th>
                                <th class="text-center">Excused</th>
                                <th class="text-end">Rate</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $data['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($r['student']->student_id); ?></td>
                                    <td><a href="<?php echo e(route('students.show', $r['student'])); ?>" class="text-decoration-none fw-semibold"><?php echo e($r['student']->name); ?></a></td>
                                    <td><?php echo e($r['student']->program); ?></td>
                                    <td class="text-center"><?php echo e($r['present']); ?></td>
                                    <td class="text-center"><?php echo e($r['late']); ?></td>
                                    <td class="text-center <?php echo e($r['absent'] > 0 ? 'value-bad' : ''); ?>"><?php echo e($r['absent']); ?></td>
                                    <td class="text-center"><?php echo e($r['excused']); ?></td>
                                    <td class="text-end fw-semibold <?php echo e(($r['rate'] ?? 100) < \App\Models\Student::ATTENDANCE_THRESHOLD ? 'value-bad' : ''); ?>">
                                        <?php echo e($r['rate'] !== null ? $r['rate'] . '%' : '—'); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted py-4">No students found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    <?php elseif($report === 'grades'): ?>

        <div class="row mb-4">
            <div class="col-md-4 mb-3">
                <div class="card stat-card shadow-hover text-center">
                    <div class="card-body">
                        <h5 class="card-title text-muted">Grades</h5>
                        <h2 class="card-text fw-bold text-primary-custom"><?php echo e($data['rows']->count()); ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card stat-card shadow-hover text-center">
                    <div class="card-body">
                        <h5 class="card-title text-muted">Average Grade</h5>
                        <h2 class="card-text fw-bold text-success"><?php echo e(number_format($data['average'], 2)); ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card stat-card shadow-hover text-center">
                    <div class="card-body">
                        <h5 class="card-title text-muted">Failed</h5>
                        <h2 class="card-text fw-bold text-danger"><?php echo e($data['failed']); ?></h2>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Grade Report</h5>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Student</th>
                                <th>Subject</th>
                                <th>Term</th>
                                <th class="text-center">Units</th>
                                <th class="text-center">Grade</th>
                                <th>Result</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $data['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($g->student->name); ?> <small class="text-muted"><?php echo e($g->student->student_id); ?></small></td>
                                    <td><?php echo e($g->subject); ?></td>
                                    <td><?php echo e($g->term_label); ?></td>
                                    <td class="text-center"><?php echo e($g->units); ?></td>
                                    <td class="text-center">
                                        <span class="badge status-badge bg-<?php echo e($g->grade_color); ?> <?php echo e($g->grade_color === 'warning' ? 'text-dark' : ''); ?>">
                                            <?php echo e(number_format((float) $g->grade, 2)); ?>

                                        </span>
                                    </td>
                                    <td class="<?php echo e($g->isPassing() ? 'value-good' : 'value-bad'); ?>"><?php echo e($g->result); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center text-muted py-4">No grades found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    <?php else: ?>

        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">At-Risk Students</h5>
                <span class="badge bg-warning text-dark"><?php echo e($data['rows']->count()); ?> student(s)</span>
            </div>

            <div class="card-body">
                <p class="text-muted small">
                    GPA below <?php echo e(number_format(\App\Models\Student::GPA_GOOD_STANDING, 2)); ?>

                    or attendance below <?php echo e(\App\Models\Student::ATTENDANCE_THRESHOLD); ?>%.
                </p>

                <div class="table-responsive">
                    <table class="table table-striped table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>Program</th>
                                <th class="text-center">GPA</th>
                                <th class="text-center">Attendance</th>
                                <th>Standing</th>
                                <th>Reasons</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $data['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($s->student_id); ?></td>
                                    <td><a href="<?php echo e(route('students.show', $s)); ?>" class="text-decoration-none fw-semibold"><?php echo e($s->name); ?></a></td>
                                    <td><?php echo e($s->program); ?></td>
                                    <td class="text-center <?php echo e($s->hasLowGpa() ? 'value-bad' : ''); ?>"><?php echo e(number_format((float) $s->gpa, 2)); ?></td>
                                    <td class="text-center <?php echo e($s->hasLowAttendance() ? 'value-bad' : ''); ?>"><?php echo e($s->attendance_rate); ?>%</td>
                                    <td>
                                        <span class="badge status-badge bg-<?php echo e($s->standing_color); ?> <?php echo e($s->standing_color === 'warning' ? 'text-dark' : ''); ?>">
                                            <?php echo e($s->academic_standing); ?>

                                        </span>
                                    </td>
                                    <td><small><?php echo e(implode('; ', $s->alert_reasons)); ?></small></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">No students need attention right now.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lab1_2411600150\lab6_2411600150\resources\views/reports/index.blade.php ENDPATH**/ ?>