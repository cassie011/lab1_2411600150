
<?php
    $unreadNotifications = auth()->user()->unreadNotifications()->latest()->take(5)->get();
    $unreadCount = auth()->user()->unreadNotifications()->count();
?>

<div class="dropdown notification-bell">

    <button
        class="btn btn-link position-relative p-1 text-primary-custom"
        type="button"
        id="notificationBell-<?php echo e($bellId); ?>"
        data-bs-toggle="dropdown"
        aria-expanded="false"
        aria-label="Academic alerts"
    >
        <i class="bi bi-bell fs-5"></i>

        <?php if($unreadCount > 0): ?>
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger notification-count">
                <?php echo e($unreadCount > 99 ? '99+' : $unreadCount); ?>

            </span>
        <?php endif; ?>
    </button>

    <div class="dropdown-menu dropdown-menu-end shadow-sm p-0 notification-menu" aria-labelledby="notificationBell-<?php echo e($bellId); ?>">

        <div class="d-flex justify-content-between align-items-center px-3 py-2 border-bottom">
            <strong class="text-primary-custom">Academic Alerts</strong>

            <?php if($unreadCount > 0): ?>
                <form method="POST" action="<?php echo e(route('notifications.readAll')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-link btn-sm p-0 text-decoration-none">
                        Mark all as read
                    </button>
                </form>
            <?php endif; ?>
        </div>

        <?php $__empty_1 = true; $__currentLoopData = $unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <a
                href="<?php echo e(route('notifications.read', $notification->id)); ?>"
                class="dropdown-item notification-item py-2"
            >
                <div class="d-flex gap-2">
                    <i class="bi bi-exclamation-triangle-fill text-warning mt-1"></i>

                    <div class="text-wrap">
                        <div class="small fw-semibold">
                            <?php echo e($notification->data['student_name'] ?? 'Academic alert'); ?>

                        </div>

                        <div class="small text-muted">
                            <?php echo e(implode('; ', $notification->data['reasons'] ?? [])); ?>

                        </div>

                        <div class="small text-muted">
                            <?php echo e($notification->created_at->diffForHumans()); ?>

                        </div>
                    </div>
                </div>
            </a>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <div class="px-3 py-4 text-center text-muted small">
                <i class="bi bi-bell-slash d-block fs-4 mb-1"></i>
                No new alerts
            </div>

        <?php endif; ?>

    </div>

</div>
<?php /**PATH C:\xampp\htdocs\lab1_2411600150\lab6_2411600150\resources\views/layouts/partials/notification-bell.blade.php ENDPATH**/ ?>